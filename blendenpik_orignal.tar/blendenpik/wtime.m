function t = wtime
% t = wtime
%
% Time eplased since 00:00:00, Jaunary 1, 1970.
%          
% 6-December 2009, Version 1.3
% Copyright (C) 2009, Haim Avron and Sivan Toledo.
